package com.myspring.myspring;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
@RestController
public class MyspringController {
    @RequestMapping
    public String Myspring() {
        return "Hello My Spring Application\n It is a Java Spring Boot Application";
    }


}
